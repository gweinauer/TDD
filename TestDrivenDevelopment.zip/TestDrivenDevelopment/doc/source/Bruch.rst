Bruch module
============

.. automodule:: bruch.Bruch
.. autoclass:: Bruch
    :members:
    :private-members:
    :special-members:
    :show-inheritance:
