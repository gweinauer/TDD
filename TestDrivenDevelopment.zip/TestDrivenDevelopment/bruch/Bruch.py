
class Bruch(object):
    def __init__(self, zaehler, nenner=1):
        '''
            create new object Bruch

        :param zaehler: hallo1
        :param nenner: hallo2
        '''
        if nenner == 0:
            raise ZeroDivisionError

        if type(zaehler) == int and type(nenner) == int:
            self.zaehler = zaehler
            self.nenner = nenner
        elif type(zaehler) == Bruch:
            self.zaehler = zaehler.zaehler
            self.nenner = zaehler.nenner
        else:
            raise TypeError

    def __float__(self):
        '''

        :return:
        '''
        return self.zaehler/self.nenner

    def __int__(self):
        '''

        :return:
        '''
        return int(self.__float__())

    def __complex__(self):
        '''

        :return:
        '''
        return complex(self.__float__())

    def __invert__(self):
        return Bruch(self.nenner, self.zaehler)

    def __str__(self):
        if self.nenner == 1:
            return "(" + str(self.zaehler) + ")"
        else:
            return "(" + str(abs(self.zaehler)) + "/" + str(abs(self.nenner)) + ")"

    def __pow__(self, power, modulo=None):
        if type(power) == int:
            return Bruch(self.zaehler ** power, self.nenner ** power)
        else:
            raise TypeError

    def __abs__(self):
        return Bruch(abs(self.zaehler), abs(self.nenner))

    def __neg__(self):
        return Bruch(-self.zaehler, self.nenner)

    def __eq__(self, other):
        return self.__float__() == other.__float__()

    def __ne__(self, other):
        return self.__float__() != other.__float__()

    def __ge__(self, other):
        return self.__float__() >= other.__float__()

    def __le__(self, other):
        return self.__float__() <= other.__float__()

    def __lt__(self, other):
        return self.__float__() < other.__float__()

    def  __gt__(self, other):
        return  self.__float__() > other.__float__()

    def __add__(self, other):
        b = Bruch(other)
        return Bruch(self.zaehler * b.nenner + b.zaehler * self.nenner, self.nenner * b.nenner)

    def __radd__(self, other):
        return self.__add__(other)

    def __iadd__(self, other):
        return self.__add__(other)

    def __sub__(self, other):
        b = Bruch(other)
        return Bruch(self.zaehler * b.nenner - b.zaehler * self.nenner, self.nenner * b.nenner)

    def __isub__(self, other):
        return self.__sub__(other)

    def __rsub__(self, other):
        b = Bruch(other)
        return Bruch(b.zaehler * self.nenner - self.zaehler * b.nenner, self.nenner * b.nenner)

    def __mul__(self, other):
        b = Bruch(other)
        return Bruch(self.zaehler * b.zaehler, self.nenner * b.nenner)

    def __imul__(self, other):
        return self.__mul__(other)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __truediv__(self, other):
        b = Bruch(other)
        return Bruch(self.zaehler * b.nenner, b.zaehler * self.nenner)

    def __rtruediv__(self, other):
        return ~self.__truediv__(other)

    def __itruediv__(self, other):
        return self.__truediv__(other)

    def __iter__(self):
        return (self.zaehler, self.nenner).__iter__()

    @staticmethod
    def __makeBruch(other):
        return Bruch(other)
